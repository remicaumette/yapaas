var limite = -1;
var start = 0;
var time = 3;
var score = 0;

function setup()
{
  button1();
  button2();
  createCanvas(1000,700);
  frameRate(100);
  button3();
}
function draw(){
      text(time, width/2, height/2);
      background(0, Player1.y, Player2.y);
      drawPlayers();
      keyHandling();
      drawBall();
    if (start == 1) {
        if (frameCount % 60 == 0 && time > 0) {
          time = time - 1;
          }
          textAlign(CENTER, CENTER);
          textSize(100);
          text(time, width/2, height/2);
    }
    if (time == 0) {
      start = 0;
      updateBall();
      collidePlayers();
      collideWall();
  }
  if (start == 3){
    background(150,150,150);
    cage();
    drawBall();
    updateBall();
    Foot();
    soloPlayer2();
    collidesPlayer1();
    collideWall2();

  }
}

var Player1 = {
    x: 40,
    y: 350,
    alive: true,
    speed: 5,

}
var Player2 = {
  x: 960,
  y: 350,
  alive: true,
  speed: 5,
}
var Player3 = {
  x: 500,
  y: 40,
  alive: true,
  speed: 5,
}
var Player4 = {
  x: 500,
  y: 660,
  alive: true,
  speed: 5,
}
 var PlayerSolo = {
   x :500,
   y: 650,
 }

//var Player3 = {
  //x: 250,
  //y: 400,
//}

function drawPlayers()
{
  stroke(255,255,255);
  strokeWeight(10);
if (Player1.alive == true)
  line(Player1.x, Player1.y - 30, Player1.x, Player1.y + 30);

if (Player2.alive == true)
  line(Player2.x, Player2.y - 30, Player2.x, Player2.y + 30);

if (Player3.alive == true)
  line(Player3.x - 40, Player3.y , Player3.x + 40, Player3.y);

if (Player4.alive == true)
  line(Player4.x - 40, Player4.y , Player4.x + 40, Player4.y);

}
  //line(Player3.x, Player3.y - 30, Player3.x, Player3.y + 30);


function keyHandling()
{
  if (keyIsDown(107))
    if (Player2.y - 30 > 0)
      Player2.y -= Player2.speed;

  if (keyIsDown(13))
      if (Player2.y + 30 < 700)
        Player2.y += Player2.speed;
  if (keyIsDown(20))
      if (Player1.y - 30 > 0)
        Player1.y -= Player1.speed;
  if (keyIsDown(16))
        if (Player1.y + 30 < 700)
          Player1.y += Player1.speed;
  if (keyIsDown(87))
    if (Player3.x -60 >0)
      Player3.x -=Player3.speed;
  if (keyIsDown(88))
      if(Player3.x + 60 < 1000)
        Player3.x +=Player3.speed;
  if (keyIsDown(37))
      if(Player4.x - 60 > 0 )
        Player4.x -=Player4.speed;
  if (keyIsDown(39))
      if(Player4.x + 60 < 1000)
        Player4.x +=Player4.speed ;
  //if (Player3.y >= 500)
    //limite = -1;
  //if (Player3.y <= 0)
  //  limite = 1;
//  Player3.y = Player3.y + 1* limite;
  //console.log(Player3.y);
}


var Ball = {
  x: 250,
  y: 250,
  red: 255,
  green: 255,
  blue: 255,
  angle: Math.random() * 360,
  speed: 5
}

function drawBall()
{

  noStroke();
  fill(Ball.red, Ball.green, Ball.blue);
  ellipse(Ball.x, Ball.y, 10, 10);
}

function updateBall()
{
  Ball.x += Ball.speed * Math.cos(Ball.angle * Math.PI / 180);
  Ball.y -= Ball.speed * Math.sin(Ball.angle * Math.PI / 180);
}

function collidePlayers()
{
  if (Ball.x < Player1.x + 10 && Ball.x > Player1.x - 10 && Ball.y < Player1.y + 30 && Ball.y > Player1.y - 30 && Player1.alive==true) {

    Ball.angle = 180 - Ball.angle;
    Ball.speed += 0.75;
    Player1.speed += 0.5;
    Ball.green -= 20;
    Ball.blue -= 20;
  }
  if (Ball.x < Player2.x + 10 && Ball.x > Player2.x - 10 && Ball.y < Player2.y + 30 && Ball.y > Player2.y - 30  && Player2.alive==true)
  {
    Ball.angle = 180 - Ball.angle;
    Ball.speed += 0.75;
    Player2.speed += 0.5;
    Ball.green -= 20;
    Ball.blue -= 20;
  }
  if (Ball.y < Player3.y + 10 && Ball.y > Player3.y - 10 && Ball.x < Player3.x + 60 && Ball.x > Player3.x - 60  && Player3.alive==true)
  {
    Ball.angle =  - Ball.angle;
    Ball.speed += 0.75;
    Player3.speed += 0.5;
    Ball.green -= 20;
    Ball.blue -= 20;
  }
  if (Ball.y < Player4.y + 10 && Ball.y > Player4.y - 10 && Ball.x < Player4.x + 60 && Ball.x > Player4.x - 60  && Player4.alive==true)
  {
    Ball.angle =  - Ball.angle;
    Ball.speed += 0.75;
    Player4.speed += 0.5;
    Ball.green -= 20;
    Ball.blue -= 20;
  }
  //else if (Ball.x < Player3.x + 10 && Ball.x > Player3.x - 10 && Ball.y < Player3.y + 30
  //  && Ball.y > Player3.y - 30)
//{
  //  Ball.angle = 180 - Ball.angle ;
  //  Ball.speed += 3;
//  }
}

function collideWall()
{
  if (Ball.x > 995) {
    Player2.alive = false;
    Ball.angle = 180 - Ball.angle;
    Ball.speed += 0.5;
  }
  if (Ball.x < 5) {
    Player1.alive = false;
    Ball.angle = 180 - Ball.angle;
    Ball.speed += 0.5;
  }
  if (Ball.y < 5) {
    Player3.alive = false;
    Ball.angle =  - Ball.angle;
    Ball.speed += 0.5;
  }
  if (Ball.y > 695) {
    Player4.alive = false;
    Ball.angle =  - Ball.angle;
    Ball.speed += 0.5;
}
  if (Player1.alive==true && Player2.alive==false && Player3.alive==false && Player4.alive==false)
    endGame("Player 1 Wins!")
  if(Player1.alive==false && Player2.alive==true && Player3.alive==false && Player4.alive==false)
    endGame("Player 2 Wins!")
  if(Player1.alive==false && Player2.alive==false && Player3.alive==true && Player4.alive==false)
      endGame("Player 3 Wins!")
  if(Player1.alive==false && Player2.alive==false && Player3.alive==false && Player4.alive==true)
      endGame("Player 4 Wins!")

}

function endGame(winner)
{
  noStroke();
  textAlign(CENTER);
  textSize(60);
  fill(255, 255, 255);
  text(winner, width / 2, height / 2);
  noLoop();
  rst();
}

function rst(){
  restart = createButton("restart");
  restart.position(450,400);
  restart.mousePressed(refresh);
  restart.class("btn btn-secondary");
}

function refresh(){
  window.location.reload();
}

function collideWall2(){
  if (Ball.y < 5)
    Ball.angle = -Ball.angle;
  if (Ball.x <5 || Ball.x >995)
    Ball.angle = 180 - Ball.angle;
  if (Ball.y > 700)
   endGame("You lose !")
}

function collidesPlayer1()
{
  if (Ball.x < PlayerSolo.x + 10 && Ball.x > PlayerSolo.x- 10 && Ball.y < PlayerSolo.y + 30 && Ball.y > PlayerSolo.y - 30)
  {
  Ball.angle = - Ball.angle;
  }
}
