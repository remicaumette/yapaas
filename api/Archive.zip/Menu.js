var button;
function button1(){
  button1 = createButton("easy");
  button1.position(500, 300);
  button1.mousePressed(speed2);
  button1.class("btn btn-success");
}

function speed2(){
  Ball.speed = 2;
  start = 1;
  button1.remove();
  button2.remove();
}

function button2(){
  button2 = createButton("hard");
  button2.position(420, 300);
  button2.mousePressed(speed3);
  button2.class("btn btn-danger");
}

function speed3(){
  Ball.speed = 4;
  start = 1;
  button1.remove();
  button2.remove();

}
function button3(){
  button3 = createButton("Foot");
  button3.position(550,350);
  button3.mousePressed(Foot);
  button3.class("btn btn-info");
}
function Foot(){
  start = 3;
  button1.remove();
  button2.remove();
  button3.remove();
}
var collider = 1;

function cage (){
  if (Ball.y >= 10) collider = 1;
  textAlign(CENTER,RIGHT);
  textSize(40);
  text(score, width/1.1, height/9);
  color("#FF0000")

  var cage1= {
    x: 350,
    y:-30,
  }
  var cage2= {
    x:650,
    y:-30,
  }
  stroke(255,255,255);
  strokeWeight(10);

  line(cage1.X , cage1.y - 30, cage1.x , cage1.y + 30)
  line(cage2.X , cage2.y - 30, cage2.x , cage2.y + 30)
  if (Ball.x < 500 + 150 && Ball.x > 500 - 150 && collider == 1 && Ball.y < 10){
        score = score + 1;
        collider = 0;
  }
  if (Ball.x < cage1.x + 5 && Ball.x > cage1.x - 5 && Ball.y < cage1.y + 1 && Ball.y > cage1.y - 1){
    Ball.angle = - Ball.angle
  }
}

function soloPlayer2 (){
  stroke(255,255,255);
  strokeWeight(10);
  line(PlayerSolo.x - 30,PlayerSolo.y , PlayerSolo.x +30, PlayerSolo.y );

  if (keyIsDown(LEFT_ARROW))
     if (PlayerSolo.x - 30 > 0)
     PlayerSolo.x -= 5;

 if (keyIsDown(RIGHT_ARROW))

     if (PlayerSolo.x + 30 < 500)
     PlayerSolo.x += 5;
}
